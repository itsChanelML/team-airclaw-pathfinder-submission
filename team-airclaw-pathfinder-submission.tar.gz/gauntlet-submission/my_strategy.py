"""Strategy for AirClaw Pathfinder: prompts, model order, and image prompts."""

from __future__ import annotations

import re

from base_strategy import BaseStrategy, ChallengeContext
from pathfinder.registry import rank_image_models, rank_text_models

# Phrases such as "no text", "avoid logos", "without watermark" become an
# explicit exclusion list, because image judges score constraints separately.
_EXCLUSION = re.compile(
    r"\b(?:no|avoid|without|never|exclude|do not include|don't include)\s+([a-z][a-z /,\-]{2,60}?)(?=[.;,\n]|$| and )",
    re.IGNORECASE,
)


def exclusions_from(*texts: str) -> list[str]:
    found: list[str] = []
    for text in texts:
        for match in _EXCLUSION.finditer(text or ""):
            item = match.group(1).strip(" ,/-").lower()
            if item and item not in found:
                found.append(item)
    return found[:6]


class MyStrategy(BaseStrategy):
    agent_id = "team-airclaw-pathfinder"
    agent_name = "AirClaw Pathfinder"

    text_system_prompt = (
        "You solve puzzles and retrieval questions from the evidence you are given. "
        "Work through it briefly: write a candidate answer, check it against every clue "
        "one at a time, and fix any violation before moving on. Keep the working short. "
        "Finish with one last line: ANSWER: <answer>. "
        "Match the requested format character for character: casing, separators, "
        "ordering, units, and number of items. "
        "Use only the supplied clues and tool evidence; if they conflict, prefer the "
        "more specific and more recent one. "
        "Never reply 'unknown': give the most likely answer that satisfies the format."
    )
    text_temperature = 0.0
    text_max_tokens = 3072
    # token budget per escalation step: quick pass first, roomier only if it came back empty
    text_token_steps = (3072, 4096, 6144)

    image_strategy_notes = (
        "Use the edit tool when a source image exists, otherwise generate. "
        "Describe subject, setting, lighting and framing; list exclusions explicitly."
    )

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if self.is_image_challenge(ctx):
            ranked = rank_image_models(available_models, editing=bool(ctx.image_url))
            return ranked or list(available_models)
        return rank_text_models(available_models)

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = "\n".join(f"{i}. {c.strip()}" for i, c in enumerate(ctx.clues, 1) if c.strip())
        parts = [
            f"Task type: {ctx.challenge_type or 'text'}",
            f"Question: {ctx.description.strip() or '(none given)'}",
        ]
        if ctx.rules.strip():
            parts.append(f"Format and rules: {ctx.rules.strip()}")
        parts.append(f"Clues and evidence:\n{clues or '(none)'}")
        parts.append("Show brief working, then end with the line ANSWER: <answer>.")
        return "\n\n".join(parts)

    def _evidence_block(self, ctx: ChallengeContext) -> str:
        clues = "\n".join(f"{i}. {c.strip()}" for i, c in enumerate(ctx.clues, 1) if c.strip())
        return (
            f"Question: {ctx.description.strip()}\n"
            f"Format and rules: {ctx.rules.strip() or '(none)'}\n"
            f"Clues and evidence:\n{clues}"
        )

    def build_check_prompt(self, ctx: ChallengeContext, answer: str) -> str:
        return (
            f"{self._evidence_block(ctx)}\n\nProposed answer: {answer}\n\n"
            "Audit the proposed answer without changing it. For each numbered clue write one line: "
            "the clue, the concrete positions or values in the proposed answer it refers to, then PASS or FAIL. "
            "Do the same for the format rule. Read each clue literally (for example, 'immediately' means adjacent). "
            "End with exactly one line: VERDICT: PASS if every line passed, otherwise VERDICT: FAIL."
        )

    def build_repair_prompt(self, ctx: ChallengeContext, answer: str, audit: str) -> str:
        return (
            f"{self._evidence_block(ctx)}\n\nA previous answer was: {answer}\n"
            f"An audit of it reported:\n{audit[-900:]}\n\n"
            "Find an answer that satisfies every clue and the format rule, checking each clue in turn. "
            "End with the line ANSWER: <answer>."
        )

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        instruction = (ctx.rules or ctx.challenge_text or ctx.description).strip()
        avoid = exclusions_from(ctx.rules, ctx.description)
        lines = [instruction]
        if ctx.image_url:
            lines.append(
                "Change only what the instruction asks for; keep everything else in the "
                "source image (layout, subjects, colors, lighting) unchanged."
            )
        else:
            lines.append(
                "One coherent scene with a clear focal subject, deliberate lighting and a "
                "clean composition. Render fine detail faithfully."
            )
        if avoid:
            lines.append("Must not contain: " + "; ".join(avoid) + ". Check the result against this list.")
        lines.append("Standard resolution only (about 1024 px on the long side).")
        return "\n\n".join(lines)
