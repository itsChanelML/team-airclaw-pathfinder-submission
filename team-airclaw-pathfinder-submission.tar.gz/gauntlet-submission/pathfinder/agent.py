#!/usr/bin/env python3
"""AirClaw Pathfinder: discover the environment, reach a result, show the evidence.

Run from the repository root:  python pathfinder/agent.py

This file only wires things together. The work lives in:
  session.py     shared state, clients, delivery
  text_flow.py   the text path
  image_flow.py  the image path
  gate.py        authorization, release review, frozen delivery
  registry.py    discovered tools and models
  ledger.py      time budget, task state, progress notes, reconnect loop
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")

from arena_clients import McpArenaClient, McpArenaError, monitor_session  # noqa: E402
from pathfinder.image_flow import ImageFlow  # noqa: E402
from pathfinder.ledger import keep_connected  # noqa: E402
from pathfinder.registry import Registry  # noqa: E402
from pathfinder.session import Session  # noqa: E402
from pathfinder.text_flow import TextFlow  # noqa: E402


class Run(TextFlow, ImageFlow, Session):
    """One agent run: the text and image flows on top of the shared session."""


async def drive(run: Run) -> None:
    """One connection's worth of work.

    The client is closed by hand with a clean exit rather than letting an error
    travel through its context manager: that path can leave the SSE stream half
    open, and the leftover cancels the next attempt. Each attempt also runs in
    its own task so a stray cancel never reaches the caller.
    """

    async def attempt() -> None:
        mcp = McpArenaClient(run.mcp_url)
        await mcp.__aenter__()
        run.mcp = mcp
        failure: BaseException | None = None
        try:
            tool_defs = await mcp.list_tool_defs()
            reg = Registry.discover(tool_defs)
            modality = McpArenaClient.detect_modality(reg.names(), agent_id=run.agent_id)
            run.observer.say(f"Discovered {len(reg.tools)} tools; this is a {modality} task.")
            if modality == "image":
                await run.run_image(mcp, reg, tool_defs)
            else:
                await run.run_text(mcp, reg)
        except BaseException as exc:  # noqa: BLE001 - re-raised after cleanup
            failure = exc
        try:
            await mcp.__aexit__(None, None, None)
        except BaseException:  # noqa: BLE001 - a dead stream may not close cleanly
            pass
        if failure is not None:
            raise failure

    await asyncio.create_task(attempt())


async def main() -> None:
    run = Run.from_environment()
    print(f"{run.agent_name} ({run.agent_id}) starting")
    # Registered exactly once; reconnects below reuse this identity.
    session = run.http.register(run.agent_id, run.agent_name)
    print(f"session: {session.session_id}")
    monitor = monitor_session(run.http, run.agent_id).start()
    try:
        await keep_connected(
            lambda: drive(run),
            done=lambda: run.gate.delivered,
            fatal=(SystemExit, McpArenaError, asyncio.CancelledError),
            on_drop=lambda n: run.observer.say("Connection dropped; reconnecting with the same identity."),
        )
    finally:
        await monitor.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
