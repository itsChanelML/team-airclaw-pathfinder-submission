"""Authorization and release control for everything the agent does.

Three separate questions are answered by three separate pieces:

* ``Policy.authorize``      -> may this action be attempted at all?  ALLOW / DENY
* ``ReleaseGate.review``    -> is the final candidate fit to send?    RELEASE / HOLD
* ``ReleaseGate.deliver``   -> what happened when it was sent?        SUCCESS / RETRY / ESCALATE

The acting code only ever *proposes* an action. The policy object is frozen at
construction and the gate keeps its own append-only, hash-chained audit trail,
so nothing downstream can quietly loosen a rule or rewrite history.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable
from urllib.parse import urlsplit


class Authority(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"


class Release(str, Enum):
    RELEASE = "RELEASE"
    HOLD = "HOLD"


class Outcome(str, Enum):
    SUCCESS = "SUCCESS"
    RETRY = "RETRY"
    ESCALATE = "ESCALATE"


class ActionKind(str, Enum):
    MODEL_CALL = "model_call"
    TOOL_CALL = "tool_call"
    PROGRESS = "progress"
    DRAFT = "draft"
    FINAL_TEXT = "final_text"
    FINAL_IMAGE = "final_image"
    PROTECTED_CHANGE = "protected_change"


# Tool names that are plain challenge capabilities. Anything outside this
# list is only usable once the challenge itself names it.
_CAPABILITY_PATTERNS = (
    re.compile(r"^arena\.(get_challenge|time_remaining|tools\.list|clues\.(list|get))$"),
    re.compile(r"^arena\.image\.(get_challenge|broadcast_thought|submit_edit)$"),
    re.compile(r"^image_(edit|generate|analyze)$"),
)

_BAD_TEXT_MARKERS = ("<toolcall", "</toolcall", "<think", '"tool_calls"', "function_call")
_MAX_TEXT_CHARS = 4000
# Below this a final answer is still sent: a late answer is judged for quality
# and only loses its speed score, so sending beats staying silent.
_LOW_TIME_S = 2.0


@dataclass(frozen=True)
class Policy:
    """Scope of authority for one run. Immutable by construction."""

    origin: str
    agent_id: str
    max_calls_per_tool: int = 6
    max_progress_messages: int = 60

    def origin_matches(self, url: str) -> bool:
        a, b = urlsplit(self.origin), urlsplit(url)
        return (a.scheme, a.hostname) == (b.scheme, b.hostname)

    def authorize(
        self,
        kind: ActionKind,
        *,
        target: str = "",
        agent_id: str = "",
        origin: str = "",
        named_by_challenge: bool = False,
    ) -> tuple[Authority, str]:
        if agent_id and agent_id != self.agent_id:
            return Authority.DENY, "identity differs from the configured agent"
        if origin and not self.origin_matches(origin):
            return Authority.DENY, "target is outside the configured arena"
        if kind in (ActionKind.MODEL_CALL, ActionKind.PROGRESS, ActionKind.DRAFT):
            return Authority.ALLOW, "bounded session operation"
        if kind in (ActionKind.FINAL_TEXT, ActionKind.FINAL_IMAGE):
            return Authority.ALLOW, "assigned final answer (still subject to review)"
        if kind is ActionKind.TOOL_CALL:
            if any(p.match(target) for p in _CAPABILITY_PATTERNS):
                return Authority.ALLOW, "known challenge capability"
            if named_by_challenge:
                return Authority.ALLOW, "tool is named by the active challenge"
            return Authority.DENY, f"tool {target!r} has no established scope"
        return Authority.DENY, "operation class has no trusted policy"


@dataclass(frozen=True)
class ChangeEvidence:
    """Everything a protected-system change must show before it is released."""

    permitted: bool = False
    scope_bounded: bool = False
    pre_state_captured: bool = False
    rollback_tested: bool = False
    verifier_measured: bool = False
    threshold_met: bool = False
    in_validated_scope: bool = False
    preconditions_current: bool = False

    def missing(self) -> list[str]:
        return [name for name, ok in self.__dict__.items() if not ok]


@dataclass
class Candidate:
    """A final answer proposed for release."""

    kind: ActionKind
    payload: str
    # image only: "generated" | "edited" | "input_fallback" | "blank"
    provenance: str = ""
    model: str = ""

    def digest(self) -> str:
        return hashlib.sha256(f"{self.kind.value}\x00{self.payload}".encode()).hexdigest()


@dataclass
class Verdict:
    decision: Release
    reasons: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)


class FinalConflict(RuntimeError):
    """A different payload was proposed after one was already frozen."""


class AuditTrail:
    """Append-only record where each entry commits to the one before it."""

    def __init__(self) -> None:
        self._entries: list[dict[str, Any]] = []
        self._head = "0" * 64

    def add(self, event: str, **detail: Any) -> None:
        body = {"t": round(time.time(), 3), "event": event, **detail}
        raw = json.dumps(body, sort_keys=True, default=str)
        self._head = hashlib.sha256((self._head + raw).encode()).hexdigest()
        self._entries.append({**body, "link": self._head})

    def entries(self) -> list[dict[str, Any]]:
        return [dict(e) for e in self._entries]

    def intact(self) -> bool:
        head = "0" * 64
        for entry in self._entries:
            body = {k: v for k, v in entry.items() if k != "link"}
            head = hashlib.sha256((head + json.dumps(body, sort_keys=True, default=str)).encode()).hexdigest()
            if head != entry["link"]:
                return False
        return True


Sender = Callable[[Candidate], Awaitable[Any]]


class ReleaseGate:
    """Single path through which every final answer must pass."""

    def __init__(self, policy: Policy, *, retries: int = 3, retry_pause_s: float = 0.6) -> None:
        self.policy = policy
        self.audit = AuditTrail()
        self._retries = retries
        self._pause = retry_pause_s
        self._frozen: Candidate | None = None
        self._receipt: Any = None
        self._delivered = False
        self._tool_calls: Counter[str] = Counter()

    @property
    def delivered(self) -> bool:
        return self._delivered

    @property
    def frozen(self) -> Candidate | None:
        return self._frozen

    # -- authority ---------------------------------------------------------
    def check(self, kind: ActionKind, **kw: Any) -> bool:
        verdict, why = self.policy.authorize(kind, **kw)
        target = kw.get("target", "")
        if verdict is Authority.ALLOW and kind is ActionKind.TOOL_CALL:
            if self._tool_calls[target] >= self.policy.max_calls_per_tool:
                verdict, why = Authority.DENY, f"call budget for {target!r} is used up"
            else:
                self._tool_calls[target] += 1
        self.audit.add("authorize", kind=kind.value, target=target, verdict=verdict.value, why=why)
        return verdict is Authority.ALLOW

    # -- release review ----------------------------------------------------
    def review(
        self,
        cand: Candidate,
        *,
        origin: str,
        agent_id: str,
        time_left_s: float,
        required_tools: list[str] | None = None,
        attempted_tools: list[str] | None = None,
    ) -> Verdict:
        reasons: list[str] = []
        caveats: list[str] = []

        verdict, why = self.policy.authorize(cand.kind, agent_id=agent_id, origin=origin)
        if verdict is Authority.DENY:
            reasons.append(why)
        if self._frozen and self._frozen.digest() != cand.digest():
            reasons.append("a different final answer is already frozen for this round")
        if time_left_s < _LOW_TIME_S:
            caveats.append("little or no time left; a late answer is still judged for quality")

        missing = [t for t in (required_tools or []) if t not in set(attempted_tools or [])]
        if missing:
            reasons.append("required tools not yet used: " + ", ".join(missing))

        if cand.kind is ActionKind.FINAL_TEXT:
            text = cand.payload.strip()
            low = text.lower()
            if not text:
                reasons.append("answer is empty")
            elif len(text) > _MAX_TEXT_CHARS:
                reasons.append("answer exceeds the allowed length")
            elif any(m in low for m in _BAD_TEXT_MARKERS):
                reasons.append("answer contains tool or reasoning markup")
            elif low in {"unknown", "n/a", "none"}:
                caveats.append("answer is a placeholder; sent as a best-effort value")
        elif cand.kind is ActionKind.FINAL_IMAGE:
            uri = cand.payload.strip()
            if not (uri.startswith("data:image/") or uri.startswith(("http://", "https://"))):
                reasons.append("image artifact is not a usable data or http URI")
            if cand.provenance == "blank":
                reasons.append("only a blank placeholder image is available")
            elif cand.provenance == "input_fallback":
                caveats.append("sending the unmodified input image; not a verified edit")
            elif cand.provenance not in {"generated", "edited"}:
                caveats.append("image provenance is unknown")
        else:
            reasons.append("not a final answer class")

        decision = Release.HOLD if reasons else Release.RELEASE
        self.audit.add("review", kind=cand.kind.value, digest=cand.digest()[:16], decision=decision.value,
                       reasons=reasons, caveats=caveats)
        return Verdict(decision, reasons, caveats)

    def review_protected_change(self, evidence: ChangeEvidence) -> Verdict:
        """Strict rule for changes to the system the agent runs inside."""
        missing = evidence.missing()
        decision = Release.HOLD if missing else Release.RELEASE
        self.audit.add("protected_change", decision=decision.value, missing=missing)
        return Verdict(decision, [f"missing evidence: {m}" for m in missing])

    # -- delivery ----------------------------------------------------------
    def freeze(self, cand: Candidate) -> None:
        if self._frozen and self._frozen.digest() != cand.digest():
            self.audit.add("freeze_refused", digest=cand.digest()[:16])
            raise FinalConflict("a different answer is already frozen")
        if not self._frozen:
            self._frozen = cand
            self.audit.add("freeze", kind=cand.kind.value, digest=cand.digest()[:16])

    async def deliver(self, cand: Candidate, send: Sender) -> tuple[Outcome, Any]:
        """Send the frozen payload; on uncertainty resend the identical one."""
        self.freeze(cand)
        if self._delivered:
            return Outcome.SUCCESS, self._receipt
        last: Exception | None = None
        for attempt in range(1, self._retries + 1):
            try:
                self._receipt = await send(self._frozen)
                self._delivered = True
                self.audit.add("delivered", attempt=attempt)
                return Outcome.SUCCESS, self._receipt
            except Exception as exc:  # noqa: BLE001 - transport errors vary
                last = exc
                text = str(exc).lower()
                if "409" in text or "conflict" in text or "already" in text:
                    # The first answer stands; nothing we send can replace it.
                    self.audit.add("conflict", attempt=attempt)
                    return Outcome.ESCALATE, exc
                self.audit.add("delivery_uncertain", attempt=attempt, error=type(exc).__name__)
                if attempt < self._retries:
                    await _sleep(self._pause * attempt)
        return Outcome.RETRY, last


async def _sleep(seconds: float) -> None:
    import asyncio

    await asyncio.sleep(seconds)
