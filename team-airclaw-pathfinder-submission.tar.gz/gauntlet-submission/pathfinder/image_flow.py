"""The image path: pick edit or generate, try models in order, release, deliver.

``ImageFlow`` is mixed into ``Run`` and relies on what ``Session`` provides.
"""

from __future__ import annotations

import asyncio

from arena_clients import McpArenaError, build_image_tool_arguments
from arena_clients.outputs import save_submitted_image
from base_strategy import ChallengeContext
from model_selector import require_explicit_model
from pathfinder.gate import ActionKind, Candidate, Release
from pathfinder.ledger import Budget
from pathfinder.registry import Registry

_BLANK_URI = "data:image/png;base64,"


class ImageFlow:
    async def run_image(self, mcp, reg: Registry, tool_defs: list) -> None:
        if self.pending:
            return await self.finish_pending()
        try:
            ch = await self.wait_for_go(mcp.get_image_challenge)
        except McpArenaError as exc:
            if not exc.is_terminal:
                raise
            # The running heat is a text one: leave the image path for good.
            self.observer.say("This heat is a text challenge; switching to the text tools.")
            return await self.run_text(mcp, reg)
        self.refresh_scope()
        self.state.challenge_id, self.state.challenge_type = ch.puzzle_id, ch.challenge_type
        budget = Budget(float(ch.max_time_s or 120))
        models = self.list_models()
        rules = "\n".join(p for p in (ch.prompt, ch.reference_notes) if p and p.strip())
        ctx = ChallengeContext(
            challenge_type=ch.challenge_type, challenge_text=ch.description, description=ch.description,
            rules=rules, max_time_s=int(ch.max_time_s or 0), available_models=models,
            image_url=ch.input_image_uri or None,
        )
        ranked = self.strategy.rank_models(ctx, models)
        require_explicit_model(ranked[0] if ranked else "", models, source="pathfinder")
        prompt = self.strategy.build_image_prompt(ctx).strip()
        have = [t for t in ("image_edit", "image_generate", "image_analyze") if reg.has(t)]
        tool = self.strategy.plan_image_tool(ctx, have)
        self.observer.say(f"Image task: using {tool or 'no tool'} with a prompt that lists what must be excluded.")

        uri, provenance, used_model = await self._make_image(mcp, tool_defs, ranked, tool, prompt, ch, budget)
        if not uri and ch.input_image_uri:
            uri, provenance = ch.input_image_uri, "input_fallback"
        if not uri:
            uri, provenance = _BLANK_URI, "blank"

        cand = Candidate(ActionKind.FINAL_IMAGE, uri, provenance=provenance, model=used_model)
        verdict = self.gate.review(
            cand, origin=self.api, agent_id=self.agent_id, time_left_s=budget.left(),
            required_tools=[tool] if tool else [], attempted_tools=self.state.attempted_tools,
        )
        if verdict.decision is Release.HOLD:
            self.observer.say("Holding the image: " + "; ".join(verdict.reasons))
            raise SystemExit("release held: " + "; ".join(verdict.reasons))
        elapsed = int(budget.used() * 1000)

        async def send(c: Candidate):
            try:
                return await self.mcp.submit_image(
                    agent_id=self.agent_id, image_uri=c.payload,
                    client_metrics=self.metrics(elapsed, planner_tool=tool), rationale=f"{provenance} via {tool}",
                )
            except Exception:  # noqa: BLE001 - same payload, other transport
                return await asyncio.to_thread(
                    self.http.submit, self.agent_id, c.payload,
                    self.metrics(elapsed, planner_tool=tool), "image",
                )

        self.observer.say("Submitting the final image.")
        await self.commit(cand, send, ch, {"provenance": provenance, "tool": tool})
        print(f"image: {save_submitted_image(self.agent_id, uri, self.output_root)}")

    async def _make_image(self, mcp, tool_defs, ranked, tool, prompt, ch, budget) -> tuple[str, str, str]:
        """Try the image models in order until one returns an image."""
        uri, provenance, used_model = "", "", ""
        for model in ranked:
            if uri or not tool or (used_model and not budget.can_afford(25)):
                break
            used_model = self.model = model
            args = {
                "prompt": prompt, "agent_id": self.agent_id,
                **build_image_tool_arguments(
                    tool_defs, tool, selected_model=model, llm_api_key=self.key, arena_api_key=self.key
                ),
            }
            if tool == "image_edit":
                args["image_uri"] = ch.input_image_uri
            if not self.gate.check(ActionKind.TOOL_CALL, target=tool):
                break
            self.state.mark_attempted(tool)
            try:
                out = await mcp.call_tool(tool, args)
            except Exception as exc:  # noqa: BLE001
                self.observer.say(f"{tool} with {model} failed ({type(exc).__name__}); trying another image model.")
                continue
            out = out if isinstance(out, dict) else {}
            uri = str(out.get("image_uri") or "").strip()
            if uri:
                provenance = "edited" if tool == "image_edit" else "generated"
            else:
                self.observer.say(f"{tool} with {model} returned no image; trying another image model.")
        return uri, provenance, used_model
