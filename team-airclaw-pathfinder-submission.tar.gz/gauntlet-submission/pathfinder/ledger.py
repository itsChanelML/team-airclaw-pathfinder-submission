"""Task state, time budget, and the observer that narrates progress."""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable
from urllib.error import URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


@dataclass
class Budget:
    """Wall-clock budget measured against the challenge's own limit."""

    limit_s: float
    started: float = field(default_factory=time.monotonic)

    def left(self) -> float:
        return self.limit_s - (time.monotonic() - self.started)

    def used(self) -> float:
        return time.monotonic() - self.started

    def can_afford(self, seconds: float, *, reserve: float = 8.0) -> bool:
        """True if an operation of ``seconds`` still leaves delivery time."""
        return self.left() - seconds >= reserve


@dataclass
class Step:
    what: str
    kind: str  # fact | hypothesis | attempt | result | blocked
    detail: str = ""


@dataclass
class TaskState:
    """Facts learned, work attempted, and evidence returned during one run."""

    challenge_id: str = ""
    challenge_type: str = ""
    required_tools: list[str] = field(default_factory=list)
    attempted_tools: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    steps: list[Step] = field(default_factory=list)
    _seen_calls: set[str] = field(default_factory=set)

    def note(self, what: str, kind: str, detail: str = "") -> None:
        self.steps.append(Step(what, kind, detail))

    def first_call(self, tool: str, args: dict[str, Any]) -> bool:
        """False when this exact call was already made (so it can be skipped)."""
        key = tool + json.dumps(args, sort_keys=True, default=str)
        if key in self._seen_calls:
            return False
        self._seen_calls.add(key)
        return True

    def mark_attempted(self, tool: str) -> None:
        if tool not in self.attempted_tools:
            self.attempted_tools.append(tool)


class Observer:
    """Sends short, de-duplicated progress lines and counts them."""

    def __init__(self, send: Callable[[str], Any], *, cap: int = 60) -> None:
        self._send = send
        self._cap = cap
        self._last = ""
        self.count = 0

    def say(self, message: str) -> None:
        message = " ".join(message.split())[:280]
        if not message or message == self._last or self.count >= self._cap:
            return
        self._last = message
        try:
            self._send(message)
            self.count += 1
        except Exception:  # noqa: BLE001 - narration must never break the run
            pass


def proxy_usage(host: str, api_key: str, agent_id: str, scope: str | None) -> dict[str, int]:
    """Best-effort token totals for this agent; zeros when unavailable."""
    base = host.rstrip("/")
    urls = []
    if scope:
        urls.append(f"{base}/usage/{quote(scope, safe='')}/{quote(agent_id, safe='')}")
    urls.append(f"{base}/usage/{quote(agent_id, safe='')}")
    for url in urls:
        req = Request(url, headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"})
        try:
            with urlopen(req, timeout=2.0) as resp:
                usage = json.loads(resp.read().decode()).get("usage") or {}
        except (URLError, ValueError, OSError):
            continue
        return {
            k: max(0, int(usage.get(k) or 0))
            for k in ("prompt_tokens", "completion_tokens", "total_tokens")
        }
    return {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}


async def keep_connected(
    attempt: Callable[[], Awaitable[None]],
    *,
    done: Callable[[], bool],
    fatal: tuple[type[BaseException], ...] = (),
    tries: int = 3,
    pause_s: float = 1.5,
    on_drop: Callable[[int], None] = lambda n: None,
) -> None:
    """Run ``attempt``; after a dropped transport run it again on a fresh one.

    The identity is never touched here. Once ``done()`` is true (the answer was
    delivered) a late error from tearing the old connection down is ignored.
    Errors listed in ``fatal`` are never retried.
    """
    for n in range(1, tries + 1):
        try:
            await attempt()
            return
        except fatal:
            raise
        except Exception:  # noqa: BLE001 - SSE drops surface as many types
            if done():
                return
            if n == tries:
                raise
            on_drop(n)
            await asyncio.sleep(pause_s * n)
