"""Small pure helpers for reading model replies and tool results."""

from __future__ import annotations

import json
import re

_ANSWER_LINE = re.compile(r"^\s*(?:final\s+)?answer\s*:\s*(.+?)\s*$", re.IGNORECASE)
_VERDICT = re.compile(r"VERDICT\s*:\s*(PASS|FAIL)", re.IGNORECASE)


def read_answer(raw: str) -> str:
    """The text after the last ``ANSWER:`` line, with markup and quotes removed."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw or "", flags=re.DOTALL)
    found = ""
    for line in cleaned.splitlines():
        m = _ANSWER_LINE.match(line)
        if m and m.group(1).strip("`\"' *"):
            found = m.group(1).strip("`\"' *")
    return found


def read_verdict(raw: str) -> bool | None:
    """True for PASS, False for FAIL, None when the reply holds no verdict."""
    found = _VERDICT.findall(raw or "")
    return found[-1].upper() == "PASS" if found else None


def flatten(result: object, limit: int = 1800) -> str:
    """Any tool result as bounded text; large inline images are left out."""
    if result is None:
        return ""
    if isinstance(result, str):
        return result[:limit]
    if isinstance(result, dict):
        slim = {k: v for k, v in result.items() if not (isinstance(v, str) and len(v) > 300 and "image" in k.lower())}
        return json.dumps(slim, ensure_ascii=False, default=str)[:limit]
    return str(result)[:limit]


def query_candidates(description: str, rules: str, clues: list[str]) -> list[str]:
    """Up to four strings worth passing to a search-like tool."""
    out: list[str] = []
    for text in [description, *clues]:
        text = (text or "").strip()
        if text and text not in out:
            out.append(text)
    for url in re.findall(r"https?://[^\s)>\"]+", " ".join([description, rules, *clues])):
        if url not in out:
            out.append(url.rstrip(".,);"))
    return out[:4]
