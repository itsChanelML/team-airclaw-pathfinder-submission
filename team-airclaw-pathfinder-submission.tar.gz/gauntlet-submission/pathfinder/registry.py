"""What the agent has learned about its surroundings at runtime.

Tools and models are read from the live environment and never assumed. Each
tool keeps its declared schema so calls can be built from it instead of by
trying payload shapes until one is accepted.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ToolRecord:
    name: str
    description: str
    properties: dict[str, Any]
    required: tuple[str, ...]

    @classmethod
    def from_def(cls, tool_def: Any) -> "ToolRecord":
        schema = getattr(tool_def, "inputSchema", None)
        schema = schema if isinstance(schema, dict) else {}
        props = schema.get("properties")
        req = schema.get("required")
        return cls(
            name=str(getattr(tool_def, "name", "") or "").strip(),
            description=str(getattr(tool_def, "description", "") or "").strip(),
            properties=props if isinstance(props, dict) else {},
            required=tuple(str(r) for r in req) if isinstance(req, list) else (),
        )

    def accepts(self, prop: str) -> bool:
        return prop in self.properties

    def build_args(self, *, agent_id: str, values: dict[str, Any]) -> dict[str, Any] | None:
        """Fill the declared properties from ``values``.

        Returns None when a required property has nothing to fill it with, so
        the caller can skip the call instead of sending a malformed one.
        """
        args: dict[str, Any] = {}
        if self.accepts("agent_id"):
            args["agent_id"] = agent_id
        for key, val in values.items():
            if self.accepts(key) and val not in (None, ""):
                args[key] = val
        if any(r not in args for r in self.required):
            return None
        return args


@dataclass
class Registry:
    tools: dict[str, ToolRecord] = field(default_factory=dict)

    @classmethod
    def discover(cls, tool_defs: list[Any]) -> "Registry":
        reg = cls()
        for d in tool_defs:
            rec = ToolRecord.from_def(d)
            if rec.name:
                reg.tools[rec.name] = rec
        return reg

    def names(self) -> list[str]:
        return list(self.tools)

    def named_in(self, *texts: str) -> list[str]:
        """Tools the challenge text refers to, by exact name or its leaf word."""
        blob = " ".join(texts).lower()
        spaced = blob.replace(" ", "_")
        return [
            name
            for name in self.tools
            if name.lower() in blob or (not name.startswith("arena.") and name.lower() in spaced)
        ]

    def has(self, name: str) -> bool:
        return name in self.tools

    def split_required(self, declared: object, already_called: set[str]) -> tuple[list[str], list[str]]:
        """Sort a challenge's declared required tools.

        Returns (to_call, unavailable). Tools the run already uses on every
        task are left out; tools this server does not offer cannot be satisfied
        and are reported separately so they never block a submission.
        """
        names = [t.strip() for t in declared if isinstance(t, str) and t.strip()] if isinstance(declared, list) else []
        to_call = [n for n in dict.fromkeys(names) if n not in already_called and n in self.tools]
        unavailable = [n for n in dict.fromkeys(names) if n not in already_called and n not in self.tools]
        return to_call, unavailable


# ----------------------------------------------------------------- models

# Hints about how a model name tends to behave, used only to order whatever
# the roster actually contains. A name that is absent is simply skipped.
_FAST = ("lightning", "flash", "mini", "lite", "haiku")
_STRONG = ("ultra", "max", "plus", "pro", "super", "terra")


def _score_text(name: str) -> tuple[int, int]:
    n = name.lower()
    if "image" in n:
        return (9, 0)
    fast = any(h in n for h in _FAST)
    strong = any(h in n for h in _STRONG)
    # Quality is weighted far above speed, so a fast model that is also not
    # weak comes first, then strong ones, then everything else in roster order.
    tier = 0 if fast else 1 if strong else 2
    return (tier, 0)


# Order measured on constraint-ordering puzzles: accuracy first, then latency.
# Only models actually present in the roster are used; the rest follow by the
# name heuristic above.
_MEASURED_TEXT = ("gpt-5.4", "gemini-3.8-flash", "gemini-3.6-flash", "nemotron-3.5-lightning")


def rank_text_models(models: list[str]) -> list[str]:
    head = [m for key in _MEASURED_TEXT for m in models if m == key]
    rest = [(i, m) for i, m in enumerate(models) if m not in head]
    return head + [m for _, m in sorted(rest, key=lambda p: (_score_text(p[1]), p[0]))]


def rank_image_models(models: list[str], *, editing: bool = False) -> list[str]:
    """Image-capable models in preference order.

    Generation favours the largest model, which follows layout and exclusion
    instructions best. Edits keep most of the source untouched, so the quick
    lite model scores the same there and finishes sooner.
    """

    def weight(m: str) -> int:
        n = m.lower()
        big, lite = "pro" in n, "lite" in n
        if editing:
            return 0 if lite else 2 if big else 1
        return 0 if big else 2 if lite else 1

    return sorted((m for m in models if "image" in m.lower()), key=weight)
