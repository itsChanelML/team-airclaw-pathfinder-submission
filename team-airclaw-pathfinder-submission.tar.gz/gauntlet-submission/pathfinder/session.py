"""State and plumbing shared by the text and image flows.

``Session`` owns the clients, the gate, the observer and the frozen answer.
Everything it touches outside the process (model roster, model client, output
folder) goes through a small method so it can be replaced in tests.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

from arena_clients import (
    HttpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from arena_clients.config import agent_id_problem
from arena_clients.display import challenge_record, save_run_record
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from model_selector import fetch_available_models
from my_strategy import MyStrategy
from pathfinder.gate import Candidate, Outcome, Policy, ReleaseGate
from pathfinder.ledger import Observer, TaskState, proxy_usage

ROOT = Path(__file__).resolve().parent.parent


class Session:
    poll_s = 2.0  # how often to ask again while the lobby is still closed

    def __init__(
        self,
        *,
        agent_id: str,
        agent_name: str,
        api: str,
        mcp_url: str,
        host: str,
        key: str,
        http: Any,
        strategy: Any,
        gate: ReleaseGate | None = None,
        output_root: Path | None = None,
    ) -> None:
        self.agent_id, self.agent_name = agent_id, agent_name
        self.api, self.mcp_url, self.host, self.key = api, mcp_url, host, key
        self.http = http
        self.strategy = strategy
        self.gate = gate or ReleaseGate(Policy(origin=api, agent_id=agent_id))
        self.output_root = output_root or ROOT
        self.state = TaskState()
        self.observer = Observer(
            lambda m: self.http.broadcast_thought(self.agent_id, m),
            cap=self.gate.policy.max_progress_messages,
        )
        self.scope: str | None = None
        self.llm: Any = None
        self.model = ""
        self.raw_text = ""
        self.mcp: Any = None
        self.pending: tuple | None = None  # (candidate, sender, challenge, extra) once frozen

    @classmethod
    def from_environment(cls):
        strategy = MyStrategy()
        agent_id = (os.getenv("AGENT_ID") or strategy.agent_id).strip()
        agent_name = (os.getenv("AGENT_NAME") or strategy.agent_name).strip()
        os.environ["AGENT_ID"], os.environ["AGENT_NAME"] = agent_id, agent_name
        problem = agent_id_problem(agent_id)
        if problem:
            raise SystemExit(f"error: {problem}")
        ensure_connected()
        api, key = get_api_base(), get_arena_api_key()
        return cls(
            agent_id=agent_id, agent_name=agent_name, api=api, mcp_url=get_mcp_url(),
            host=get_proxy_host(), key=key, http=HttpArenaClient(api_base=api, api_key=key),
            strategy=strategy,
        )

    # ------------------------------------------------------- outside world
    def list_models(self) -> list[str]:
        return fetch_available_models(self.host, self.key)

    def make_llm(self) -> None:
        from openai import OpenAI

        self.llm = OpenAI(
            base_url=self.host, api_key=self.key,
            default_headers=build_proxy_headers(self.agent_id, self.scope),
        )

    def ask(self, model: str, system: str, user: str, params: dict, timeout: float):
        """One chat completion: (text, finish_reason, milliseconds)."""
        t0 = time.monotonic()
        resp = self.llm.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            max_tokens=int(params.get("max_tokens", 4096)),
            temperature=float(params.get("temperature", 0.0)),
            timeout=max(5.0, timeout),
        )
        choice = resp.choices[0]
        return (choice.message.content or ""), str(choice.finish_reason or ""), int((time.monotonic() - t0) * 1000)

    def metrics(self, elapsed_ms: int, ttft_ms: int = 0, planner_tool: str = "") -> dict:
        u = proxy_usage(self.host, self.key, self.agent_id, self.scope)
        m = {
            "model_name": self.model,
            "total_tokens": str(u["total_tokens"]),
            "prompt_tokens": str(u["prompt_tokens"]),
            "completion_tokens": str(u["completion_tokens"]),
            "ttft_ms": ttft_ms,
            "total_time_ms": elapsed_ms,
        }
        if planner_tool:
            m["planner_tool"] = planner_tool
        return m

    def refresh_scope(self) -> None:
        self.scope = self.http.fetch_usage_scope() or resolve_usage_scope()
        if self.scope:
            os.environ["ARENA_USAGE_SCOPE"] = self.scope

    async def wait_for_go(self, fetch):
        """Ask for the challenge until the round has started."""
        while True:
            try:
                return await fetch(self.agent_id)
            except McpArenaError as exc:
                low = str(exc).lower()
                if "locked" in low or "waiting for organizer" in low:
                    self.observer.say("Lobby is open; waiting for the round to start.")
                    await asyncio.sleep(self.poll_s)
                else:
                    raise

    # ----------------------------------------------------------- delivery
    async def commit(self, cand: Candidate, send, ch, extra: dict):
        """Freeze the answer, send it, and report. The only way a final goes out."""
        self.gate.freeze(cand)
        self.pending = (cand, send, ch, extra)
        outcome, receipt = await self.gate.deliver(cand, send)
        self.report(outcome, receipt, ch, extra)
        return outcome, receipt

    async def finish_pending(self) -> None:
        """After a reconnect: resend the already-frozen answer, nothing new."""
        cand, send, ch, extra = self.pending
        self.observer.say("Reconnected; resending the same final answer.")
        outcome, receipt = await self.gate.deliver(cand, send)
        self.report(outcome, receipt, ch, extra)

    # ------------------------------------------------------------- records
    def keep_history(self, record: dict) -> None:
        """Local per-run archive under outputs/, which is never packaged."""
        try:
            folder = self.output_root / "outputs" / "history"
            folder.mkdir(parents=True, exist_ok=True)
            body = {**record, "raw_answer": self.raw_text[-1500:], "steps": [s.__dict__ for s in self.state.steps]}
            (folder / f"{int(time.time())}-{self.state.challenge_id}.json").write_text(
                json.dumps(body, indent=1, default=str)
            )
        except OSError:
            pass

    def report(self, outcome: Outcome, receipt, ch, extra: dict) -> None:
        if isinstance(receipt, dict):
            accepted, score = receipt.get("accepted"), receipt.get("score")
        else:
            accepted, score = getattr(receipt, "accepted", None), getattr(receipt, "score", None)
        score = score if isinstance(score, dict) else {}
        print(f"delivery: {outcome.value}  accepted: {accepted}  final: {score.get('final_score')}")
        record = {
            "agent_id": self.agent_id,
            "challenge": challenge_record(ch),
            "model": self.model,
            "outcome": outcome.value,
            "audit_intact": self.gate.audit.intact(),
            "progress_messages": self.observer.count,
            "result": {"accepted": accepted, "score": {k: v for k, v in score.items() if k != "output_image_uri"}},
            **extra,
        }
        print(f"record: {save_run_record(self.agent_id, record, self.output_root)}")
        self.keep_history(record)
