"""The text path: gather evidence, solve, check, release, deliver.

``TextFlow`` is mixed into ``Run`` and relies on the attributes and helpers
that ``Session`` provides (clients, gate, observer, state, ``ask``, ``commit``).
"""

from __future__ import annotations

import asyncio

from base_strategy import ChallengeContext
from model_selector import require_explicit_model
from pathfinder.gate import ActionKind, Candidate, Release
from pathfinder.ledger import Budget
from pathfinder.parsing import flatten, query_candidates, read_answer, read_verdict
from pathfinder.registry import Registry

_TOOL_VALUE_KEYS = ("query", "search_query", "question", "text", "url", "video_url")
_NON_EVIDENCE_PREFIXES = ("arena.", "image_")
# Read on every text task already, so a challenge listing them is satisfied.
_ALWAYS_CALLED = {"arena.get_challenge", "arena.clues.list", "arena.clues.get", "arena.time_remaining"}


class TextFlow:
    async def gather_evidence(self, mcp, reg: Registry, ch, clues: list[str]) -> None:
        wanted = [
            t for t in reg.named_in(ch.challenge_type, ch.description, ch.rules, getattr(ch, "extra_text", ""))
            if not t.startswith(_NON_EVIDENCE_PREFIXES)
        ]
        if ch.challenge_type.strip().lower() in {"web-search", "market-research"}:
            wanted += [n for n in reg.names() if "search" in n.lower() and n not in wanted]
        raw = getattr(ch, "raw_data", None)
        declared = raw.get("required_tools") if isinstance(raw, dict) else None
        listed, unavailable = reg.split_required(declared, _ALWAYS_CALLED)
        wanted += [n for n in listed if n not in wanted]
        for n in unavailable:
            self.state.note(n, "blocked", "listed as required but not offered by this server")
        if unavailable:
            self.observer.say("A listed tool is not offered here: " + ", ".join(unavailable) + ".")
        self.state.required_tools = wanted
        queries = query_candidates(ch.description, ch.rules, clues) or [""]
        for name in wanted:
            tool = reg.tools[name]
            if not self.gate.check(ActionKind.TOOL_CALL, target=name, named_by_challenge=True):
                self.state.note(name, "blocked", "policy denied")
                continue
            self.observer.say(f"Using {name} to gather evidence the question depends on.")
            self.state.mark_attempted(name)
            for q in queries[: 2 if "search" in name.lower() else 1]:
                args = tool.build_args(agent_id=self.agent_id, values={k: q for k in _TOOL_VALUE_KEYS})
                if args is None or not self.state.first_call(name, args):
                    continue
                try:
                    out = await mcp.call_tool(name, args)
                except Exception as exc:  # noqa: BLE001
                    self.state.note(name, "attempt", f"failed: {type(exc).__name__}")
                    continue
                text = flatten(out)
                if text:
                    self.state.evidence.append(f"{name}: {text}")
                    self.state.note(name, "result", text[:120])

    async def solve_text(self, ranked: list[str], ctx: ChallengeContext, budget: Budget) -> tuple[str, int]:
        system = self.strategy.build_system_prompt(ctx)
        user = self.strategy.build_solver_prompt(ctx)
        params = self.strategy.get_llm_params(ctx)
        tried: list[str] = []
        steps = tuple(getattr(self.strategy, "text_token_steps", (params.get("max_tokens", 2048),)))
        for model in ranked:
            if model in tried or (tried and not budget.can_afford(15)):
                continue
            params = {**params, "max_tokens": steps[min(len(tried), len(steps) - 1)]}
            tried.append(model)
            self.model = model
            self.observer.say(f"Working the question with {model}.")
            try:
                raw, finish, ms = await asyncio.to_thread(
                    self.ask, model, system, user, params, min(budget.left() - 8, max(15.0, budget.limit_s * 0.45))
                )
            except Exception as exc:  # noqa: BLE001
                self.observer.say(f"{model} did not respond ({type(exc).__name__}); trying another model.")
                continue
            self.raw_text = raw
            answer = read_answer(raw)
            if answer:
                if ctx.clues and budget.can_afford(20):
                    answer, extra_ms = await self.verify(model, ctx, answer, params, budget)
                    ms += extra_ms
                return answer, ms
            self.observer.say(f"{model} returned no usable answer ({finish or 'empty'}); trying another model.")
        return "", 0

    async def audit(self, model, ctx, answer, params, budget) -> tuple[bool | None, str, int]:
        """PASS/FAIL review of one candidate; None when the review is unreadable."""
        try:
            raw, _finish, ms = await asyncio.to_thread(
                self.ask, model, self.strategy.build_system_prompt(ctx),
                self.strategy.build_check_prompt(ctx, answer), {**params, "max_tokens": 4096},
                min(budget.left() - 8, 25.0),
            )
        except Exception:  # noqa: BLE001
            return None, "", 0
        return read_verdict(raw), raw, ms

    async def verify(self, model, ctx, answer, params, budget) -> tuple[str, int]:
        """Test the candidate against each clue. A different answer is adopted
        only if it passes its own audit; otherwise the original stands."""
        self.observer.say("Checking the candidate against each clue.")
        ok, report, spent = await self.audit(model, ctx, answer, params, budget)
        if ok is not False or not budget.can_afford(25):
            return answer, spent
        self.observer.say("The check flagged a clue; looking for a corrected answer.")
        try:
            raw, _f, ms = await asyncio.to_thread(
                self.ask, model, self.strategy.build_system_prompt(ctx),
                self.strategy.build_repair_prompt(ctx, answer, report), {**params, "max_tokens": 4096},
                min(budget.left() - 8, 25.0),
            )
        except Exception:  # noqa: BLE001
            return answer, spent
        spent += ms
        revised = read_answer(raw)
        if not revised or revised == answer or not budget.can_afford(12):
            return answer, spent
        ok2, _r, ms2 = await self.audit(model, ctx, revised, params, budget)
        spent += ms2
        if ok2:
            self.observer.say("The corrected answer passes every clue.")
            return revised, spent
        return answer, spent

    async def run_text(self, mcp, reg: Registry) -> None:
        if self.pending:
            return await self.finish_pending()
        ch = await self.wait_for_go(mcp.get_challenge)
        self.state.mark_attempted("arena.get_challenge")
        self.refresh_scope()
        self.state.challenge_id, self.state.challenge_type = ch.puzzle_id, ch.challenge_type
        budget = Budget(float(ch.max_time_s or 60))
        self.make_llm()
        self.observer.say("Reading the challenge and its clues.")
        clues: list[str] = []
        clue_ids = await mcp.list_clues(self.agent_id)
        self.state.mark_attempted("arena.clues.list")
        for cid in clue_ids:
            clues.append((await mcp.get_clue(cid, self.agent_id)).text)
            self.state.mark_attempted("arena.clues.get")
        clues = clues or [str(c) for c in ch.clues]
        await self.gather_evidence(mcp, reg, ch, clues)
        self.http.save_draft(self.agent_id, "working", "evidence gathered")

        models = self.list_models()
        ctx = ChallengeContext(
            challenge_type=ch.challenge_type, challenge_text=ch.description, description=ch.description,
            rules=ch.rules, clues=clues + self.state.evidence, max_time_s=int(ch.max_time_s or 0),
            available_models=models,
        )
        ranked = self.strategy.rank_models(ctx, models)
        require_explicit_model(ranked[0] if ranked else "", models, source="pathfinder")
        answer, solve_ms = await self.solve_text(ranked, ctx, budget)
        if not answer:
            answer = "unknown"
        self.http.save_draft(self.agent_id, answer, "candidate")
        self.observer.say(f"Candidate answer ready: {answer[:80]}")

        info = await mcp.time_remaining(self.agent_id)
        self.state.mark_attempted("arena.time_remaining")
        try:
            left = float(info["time_remaining_s"]) if isinstance(info, dict) else budget.left()
        except (KeyError, TypeError, ValueError):
            left = budget.left()
        cand = Candidate(ActionKind.FINAL_TEXT, answer, model=self.model)
        verdict = self._review_text(cand, left)
        if verdict.decision is Release.HOLD:
            self.observer.say("Holding the answer: " + "; ".join(verdict.reasons))
            if any("required tools" in r for r in verdict.reasons):
                await self.gather_evidence(mcp, reg, ch, clues)
            verdict = self._review_text(cand, left)
            if verdict.decision is Release.HOLD:
                raise SystemExit("release held: " + "; ".join(verdict.reasons))

        elapsed = int(budget.used() * 1000)

        async def send(c: Candidate):
            return await asyncio.to_thread(
                self.http.submit, self.agent_id, c.payload, self.metrics(elapsed, solve_ms)
            )

        self.observer.say("Submitting the final answer.")
        await self.commit(cand, send, ch, {"answer": answer})

    def _review_text(self, cand: Candidate, left: float):
        return self.gate.review(
            cand, origin=self.api, agent_id=self.agent_id, time_left_s=left,
            required_tools=self.state.required_tools, attempted_tools=self.state.attempted_tools,
        )
